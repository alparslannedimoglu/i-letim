package Alparslan;

import java.io.IOException;
import java.util.Scanner;

import Copmonents.*;

public class Main {
	
	public static void main(String[] args) throws IOException {
		try (Scanner read = new Scanner(System.in)) {
			String raw = "girdi.txt";
			
			_18670310078_CPU cpu = new _18670310078_CPU();
			
			System.out.println("girdi.txt dosyası okundu."+"\nLütfen RAM’in durumunu görmek istediğiniz saniyeyi giriniz.");
			int target = read.nextInt();
			cpu.start(raw, target);
			cpu.showMemory();
			System.out.println(target+". saniyedeki PCB’sini görüntülemek istediğiniz proses ismini giriniz:");
			String isim = read.next();
			System.out.println(isim +" isimli prosesin "+target+". Saniyedeki PCB bilgileri şu şekildedir:");
			cpu.showProcess(isim);
		}
		
	}
}
