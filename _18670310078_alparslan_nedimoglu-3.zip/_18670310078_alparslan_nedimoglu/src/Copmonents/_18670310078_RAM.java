package Copmonents;

import java.util.TreeMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NavigableMap;
import java.util.Set;

public class _18670310078_RAM {

	public static NavigableMap<Integer, _18670310078_PCB> registors = new TreeMap<>();
	
	public static void allocate(_18670310078_PCB pcb) {
		if (registors.isEmpty())
			registors.put(1024000, pcb);
		else {
			Iterator<Integer> itr = registors.keySet().iterator();
			while(itr.hasNext()) {
				int i = itr.next();
				_18670310078_PCB prevPCB = registors.get(i);
				if (!prevPCB.durum.equals("Terminated")) continue;
				int size = prevPCB.size;
				if (pcb.size <= prevPCB.size) {
					pcb.durum = "Ready";
					registors.put(i, pcb);
					return;
				}
			}
			
			_18670310078_PCB prev = registors.get(registors.lastKey());
			prev.durum = "Ready";
			int physicalAddress = registors.lastKey() + prev.size*1024;
			if (physicalAddress > 1024*1024*10 - 1) return;
			registors.put(physicalAddress, pcb);	
		}
	}
	
	public static void deallocate(int address) {
		registors.get(address).durum = "Terminated";
	}
	
	public static void cleanMemory(int target) {
		Set<Integer> raw = new HashSet<>(registors.keySet());
		Iterator<Integer> itr = raw.iterator();
		while(itr.hasNext()) {
			int i = itr.next();
			short totalTime = (short) (registors.get(i).allocatedTime + registors.get(i).process.bitis);
			if (totalTime <= target) deallocate(i);
		}
	}
	
	public static void getInfo() {
		Iterator<Integer> itr = registors.keySet().iterator();
		String procs = "";
		System.out.println("0. Ve 1023999. Adresler arasında işletim sistemi bulunmaktadır.");
		while(itr.hasNext()) {
			int i = itr.next();
			String out = i + ". Ve ";
			out += (i + registors.get(i).size*1024 - 1);
			out += " Adresler arasında ";
			out += registors.get(i).process.isim;
			procs += registors.get(i).process.isim + " ";
			out += " programı bulunmaktadır.";
			System.out.println(out);
		}
		System.out.println("PCB’si bulunan Prosesler: "+procs);
	}
	
}

