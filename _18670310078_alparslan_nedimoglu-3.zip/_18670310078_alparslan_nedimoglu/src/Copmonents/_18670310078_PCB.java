package Copmonents;

public class _18670310078_PCB {
	
	public int pid;
	public String durum;
	public int size;
	public int allocatedTime;
	public _18670310078_Process process;
	
	public _18670310078_PCB(int pid) {
		this.pid = 1000 + pid;
		durum = "Waiting";
	}
	public _18670310078_PCB(int pid, _18670310078_Process process) {
		this.pid = 1000 + pid;
		durum = "Waiting";
		this.process = process;
		this.size = process.data + process.code + process.stack + process.heap;
	}
	
	public String toString() {
		String out = "";
		out += "Proses numarası: "+pid+"\n";
		out += "Prosesin yaratılma zamanı: "+process.baslangic+". saniye\n";
		out += "Prosesin toplam büyüklüğü: "+size+" KB";
		return out;
		
	}
}
