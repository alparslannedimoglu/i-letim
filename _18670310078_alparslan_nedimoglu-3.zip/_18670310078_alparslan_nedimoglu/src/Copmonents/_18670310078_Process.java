package Copmonents;

public class _18670310078_Process {
	
	public String isim;
	public int data;
	public int code;
	public int stack;
	public int heap;
	public short baslangic;
	public short bitis;
	
	public _18670310078_Process(String raw) {
		for (int i = 0; i < 7; i++) {
			switch(i) {
			case 0:{
				isim = raw.split(" ")[i];
				break;}
			case 3:{
				data = Integer.parseInt(raw.split(" ")[i]);
				break;}
			case 4:{
				code = Integer.parseInt(raw.split(" ")[i]);
				break;}
			case 5:{
				stack = Integer.parseInt(raw.split(" ")[i]);;
				break;}
			case 6:{
				heap = Integer.parseInt(raw.split(" ")[i]);
				break;}
			case 1:{
				baslangic = Short.parseShort(raw.split(" ")[i]);
				break;}
			case 2:{
				bitis = Short.parseShort(raw.split(" ")[i]);
				break;}
			}
		}
	}	
	
}
