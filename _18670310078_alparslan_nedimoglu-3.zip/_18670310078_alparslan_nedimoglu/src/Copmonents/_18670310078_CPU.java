package Copmonents;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class _18670310078_CPU {

	List<_18670310078_PCB> pcbs = new ArrayList<>();
	short numOfPCBs;
	
	public _18670310078_CPU() {
		numOfPCBs = -1;
	}
	
	public short getNumOfPCBs() {
		return numOfPCBs;
	}
	public void setNumOfPCBs() {
		this.numOfPCBs += 1;
	}
	
	public _18670310078_PCB allocate(_18670310078_Process process) {
		setNumOfPCBs();
		_18670310078_PCB pcb = new _18670310078_PCB(numOfPCBs, process);
		_18670310078_RAM.allocate(pcb);
		return pcb;
	}
	
	public void start (String raw) throws IOException {
		try (BufferedReader buffer = new BufferedReader(new FileReader(raw))) {
			raw = buffer.readLine();
			while (raw != null) {
				_18670310078_PCB a = allocate(new _18670310078_Process(raw));
				pcbs.add(a);
				raw = buffer.readLine();
			}
		}
	}

	public void start (String raw, int target) throws IOException {
		ArrayList<String> programs = new ArrayList<>();
		try (BufferedReader buffer = new BufferedReader(new FileReader(raw))) {
			raw = buffer.readLine();
			int time = 0;
			while (raw != null) {
				programs.add(raw);
				raw = buffer.readLine();
			}
			helper h = new helper();
			programs.sort(h);
			for (String r: programs) {
				_18670310078_Process proc = new _18670310078_Process(r);
				if (proc.baslangic <= target) {
					_18670310078_PCB pcb = allocate(proc);
					pcb.allocatedTime = time;
					 pcbs.add(pcb);
				}
				time += proc.baslangic;
				cleanMemory(time, target);
				if (time - proc.baslangic > target) return;
			}
		}
	}
	
	public void cleanMemory(int t1, int t2) {
		_18670310078_RAM.cleanMemory((t1<t2)?t1:t2);
	}
	
	public void showMemory() {
		_18670310078_RAM.getInfo();
	}
	
	public void showProcess(String raw) {
		for (_18670310078_PCB pcb: pcbs) {
			if (pcb.process.isim.equals(raw) & !pcb.durum.equals("Terminated")) {
				System.out.println(pcb);
				return;
			}
		}
		System.out.println("Proses bulunamadı");
	}
}
